export default function Home() {
  return (
    <main style={{ backgroundColor: 'black', color: 'white', textAlign: 'center', padding: '3rem', fontFamily: 'Arial' }}>
      <h1 style={{ fontSize: '3rem', color: '#00ff00' }}>KAPITANZACHAR</h1>
      <p style={{ color: 'red', fontWeight: 'bold' }}>🔴 Codziennie streamy o 19:00</p>
      <div style={{ marginTop: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem', alignItems: 'center' }}>
        <a href="https://instagram.com/kapitanzachar" target="_blank" style={linkStyle}>Instagram</a>
        <a href="https://kick.com/kapitanzachar" target="_blank" style={linkStyle}>Kick</a>
        <a href="https://discord.gg/kapitanzachar" target="_blank" style={linkStyle}>Discord</a>
      </div>
    </main>
  );
}

const linkStyle = {
  color: '#00ff00',
  border: '2px solid #00ff00',
  padding: '0.8rem 2rem',
  borderRadius: '10px',
  textDecoration: 'none',
  width: '200px',
  transition: '0.3s',
  textAlign: 'center'
};

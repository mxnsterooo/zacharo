# KapitanZachar – Next.js Strona

Prosta strona stworzona w Next.js zawierająca linki społecznościowe i informację o streamach.

## 🔗 Linki

- Instagram: [instagram.com/kapitanzachar](https://instagram.com/kapitanzachar)
- Kick: [kick.com/kapitanzachar](https://kick.com/kapitanzachar)
- Discord: [discord.gg/kapitanzachar](https://discord.gg/kapitanzachar)

## 🚀 Uruchomienie lokalne

```bash
npm install
npm run dev
```
